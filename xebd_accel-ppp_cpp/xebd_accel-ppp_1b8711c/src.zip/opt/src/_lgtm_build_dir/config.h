//#define ACCEL_PPP_VERSION "1.12.0-151-g1b8711c"
/* #undef RADIUS */
#define HAVE_IPSET
#define HAVE_SETNS
