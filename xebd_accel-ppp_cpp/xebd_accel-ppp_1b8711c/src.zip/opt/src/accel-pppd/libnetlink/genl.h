#ifndef __GENL_H
#define __GENL_H

int genl_resolve_mcg(const char *family, const char *name, int *fam_id);

#endif
